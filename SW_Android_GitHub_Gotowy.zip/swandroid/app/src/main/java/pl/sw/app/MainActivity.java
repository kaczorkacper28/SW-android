package pl.sw.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density+0.5f); }
    TextView text(String s,float size,int color,boolean bold){ TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setGravity(Gravity.CENTER_VERTICAL); t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL); return t; }
    GradientDrawable bg(int color,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(color); g.setCornerRadius(dp(r)); return g; }
    Button tile(String label){ Button b=new Button(this); b.setText(label); b.setTextSize(15); b.setTextColor(Color.WHITE); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setGravity(Gravity.CENTER); b.setBackground(bg(Color.rgb(25,43,61),8)); b.setOnClickListener(v->Toast.makeText(this,label,Toast.LENGTH_SHORT).show()); return b; }
    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }
    void build(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(14),dp(10),dp(14),0); root.setBackgroundColor(Color.rgb(5,18,31));
        TextView title=text("SŁUŻBA WIĘZIENNA",22,Color.WHITE,true); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,dp(52)));
        TextView radio=text("●  Radiostacja: POŁĄCZONA                         12:45",15,Color.WHITE,true); radio.setPadding(dp(14),0,dp(8),0); radio.setBackground(bg(Color.rgb(16,102,197),7)); root.addView(radio,new LinearLayout.LayoutParams(-1,dp(48)));
        TextView channel=text("   Kanał: SŁUŻBA 1                         / zmień kanał",14,Color.LTGRAY,false); channel.setPadding(dp(4),0,0,0); root.addView(channel,new LinearLayout.LayoutParams(-1,dp(42)));
        TextView status=text("🛡  Status funkcjonariusza: AKTYWNY                 / zmień status",14,Color.WHITE,true); status.setPadding(dp(12),0,0,0); status.setBackground(bg(Color.rgb(20,166,91),7)); root.addView(status,new LinearLayout.LayoutParams(-1,dp(50)));
        GridLayout grid=new GridLayout(this); grid.setColumnCount(2); grid.setRowCount(4); grid.setUseDefaultMargins(false); String[] a={"🪪\nLEGITYMOWANIE","⛓\nINTERWENCJA WŁASNA","💬\nKOMUNIKATY","📋\nZDARZENIA","👥\nMELDUNKI","🛡\nDYSPOZYCJE","📝\nNOTATKI","⚙\nOPCJE"};
        for(int i=0;i<a.length;i++){ Button v=tile(a[i]); GridLayout.LayoutParams p=new GridLayout.LayoutParams(); p.width=0; p.height=dp(105); p.columnSpec=GridLayout.spec(i%2,1,1f); p.rowSpec=GridLayout.spec(i/2); p.setMargins(dp(4),dp(4),dp(4),dp(4)); grid.addView(v,p); }
        root.addView(grid,new LinearLayout.LayoutParams(-1,0,1));
        TextView foot=text("v1.0.0                                      SW Mobile",11,Color.LTGRAY,false); foot.setGravity(Gravity.CENTER); root.addView(foot,new LinearLayout.LayoutParams(-1,dp(42)));
        setContentView(root);
    }
}
