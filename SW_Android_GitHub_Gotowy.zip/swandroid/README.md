# SW-Android

Mobilna aplikacja RP dla Służby Więziennej.

## Budowanie APK bez komputera
1. Wgraj wszystkie pliki do repozytorium GitHub.
2. Wejdź w **Actions**.
3. Uruchom **Build SW APK** przez **Run workflow**.
4. Po zakończeniu otwórz wykonany workflow i pobierz artefakt **SW-Mobile-APK**.
